# -----------------------------------------------------------------------------
# byField_FinancialAnlaysis.py
# 
#  A tool for examining costs and benefits from selected ACPF conservation practices
# -----------------------------------------------------------------------------
#  Orginal coding: D.James 06/2020
#  Conceptual underpinnings & early workflow: Emily Zimmerman, 2019, see
#     Zimmerman, E.K., Tyndall, J.C. & Schulte, L.A. Using Spatially Targeted 
#      Conservation to Evaluate Nitrogen Reduction and Economic Opportunities
#      for Best Management Practice Placement in Agricultural Landscapes. 
#      Environmental Management 64, 313-328 (2019). 
#      https://doi.org/10.1007/s00267-019-01190-7
# -----------------------------------------------------------------------------
# K. Karnish 12/2024
# $/point values added for all MLRAs 
# -----------------------------------------------------------------------------

# Import system modules
import arcpy
from arcpy import env
from arcpy.sa import *
from arcpy import metadata as md
import sys, string, os, os.path, getpass
import json, ssl, urllib
from urllib.request import urlopen
from datetime import datetime
import math

env.overwriteOutput = True
env.parallelProcessingFactor = "80%"

# Set extensions & environments 
arcpy.CheckOutExtension("Spatial")


##--------------------------------------------------------------------------------------
## Modules
## 

def joinCheck(lyr):
    
    fields = arcpy.Describe(lyr).fields
    basename = arcpy.Describe(lyr).baseName
    for field in fields:
        if field.name.find(basename) == 0:
            return True
    return False
    

def DeleteFields(inlyr, keepList):

    # delete fields not in list of fields 
    dropList = []
    fieldList = arcpy.ListFields(inlyr)
    for f in fieldList:
        if f.name not in keepList:
            if not f.required:
                dropList.append(f.name)
    if len(dropList) > 0:
        arcpy.DeleteField_management(inlyr, dropList)

def getMLRA(inFBnd):
    d = arcpy.Describe(inFBnd)
    xCoord = d.extent.XMin
    yCoord = d.extent.YMin
    inSR = d.SpatialReference.factoryCode

    # The US MLRA feature service (ArcGIS Online) URL and query arguments for the feature service - output in json
    # uri = "https://services.arcgis.com/SXbDpmb7xQkk44JV/arcgis/rest/services/US_MLRA/FeatureServer/query?"   ## factory code = 4269
    # payload = {"layerDefs":"[{'layerId':'0','where':'OBJECTID>0','outFields':'MLRARSYM,MLRA_NAME'}]",'geometry':'429307,4630946','geometryType':'esriGeometryPoint','inSR':'26915','spatialRel':'esriSpatialRelIntersects','outSR':'4269','datumTransformation':'','applyVCSProjection':'false','returnGeometry':'false','maxAllowableOffset':'','geometryPrecision':'4','sqlFormat':'standard','f':'pjson','token':''}

    # the ISU GISF MLRA/CO feature service - 2022
    uri = "https://ortho.gis.iastate.edu/arcgis/rest/services/ACPF/MLRA/FeatureServer/query?"
    payload = {"layerDefs": "[{'layerId':'1','where':'FID>0','outFields':'MLRARSYM,MLRA_NAME,WaterLeach'}]",
               'geometry': '429307,4630946', 'geometryType': 'esriGeometryPoint', 'inSR': '26915',
               'spatialRel': 'esriSpatialRelIntersects', 'outSR': '102039', 'datumTransformation': '',
               'applyVCSProjection': 'false', 'returnGeometry': 'false', 'maxAllowableOffset': '',
               'geometryPrecision': '4', 'sqlFormat': 'standard', 'f': 'pjson', 'token': ''}

    # update the geometry and spatial reference from the input feature class
    payload['geometry'] = '%s,%s' % (xCoord, yCoord)
    payload['inSR'] = inSR
    payload['outSR'] = inSR

    # encode the query
    # for Pro & python 3x
    data = urllib.parse.urlencode(payload).encode("utf-8")
    req = urllib.request.Request(uri, data)

    # arcpy.AddMessage(data)
    # certificate handling tnx AKHerz
    # cerificate applied for Python 3
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    jDict = json.loads(urllib.request.urlopen(req, context=ctx).read())
    #arcpy.AddMessage(jDict)

    inMLRA = jDict['layers'][0]['features'][0]['attributes']['MLRARSYM']
    MLRA_NAME = jDict['layers'][0]['features'][0]['attributes']['MLRA_NAME']

    arcpy.AddMessage('You are working in MLRA: %s - %s' % (inMLRA, MLRA_NAME))

    return (inMLRA)

def getRentRate(inMLRA):
    # $/point values by MLRA in 2024$
    rRateDict = {"102C": 3.81,"103":3.53,"104":3.63,"105":4.23,"107A":3.68,"107B":3.86,"108C":3.26,"108D":3.11,"109":2.92,"115C":3.35}
    rRate = rRateDict.get(inMLRA)

    arcpy.AddMessage('$/Point is: %s ' % (rRate))

    return (rRate)


def calcAgAcres(inFBnd):
    # calculate the total Ag Acres
    ##-------------------------------------------------------------------------
    #arcpy.AddMessage("Calculating Ag acres...")
    
    arcpy.MakeTableView_management(inFBnd, "TView", "", "in_memory")

    theField = ["Acres"]
    rows = arcpy.da.SearchCursor("TView", theField, "isAG > 0")
    AgAcres = 0
    for row in rows:
        AgAcres = row[0] + AgAcres

    del row
    del rows
    del theField
    #arcpy.AddMessage("Watershed Agricultural Acres: %.1f" % AgAcres) 
    arcpy.AddMessage('Watershed Agricultural Acres: {0:,.1f}'.format(AgAcres))
    
    return(AgAcres)
    
    
def getwsNLoad(inFB_NPTable):
    # calculate watershed N Load...
    values = [row[0] for row in arcpy.da.SearchCursor(inFB_NPTable, "wsNLoad", "isAG > 0")]
    wsTotalNLoad = 0
    for v in values: 
        if v is not None:
            wsTotalNLoad = wsTotalNLoad + v
    
    return(wsTotalNLoad)            
        

def mkFB_NReductionTable(inFBnd, outScnTable, inLU6):
    # Create the output structure for the Scenario Summary Table
    #  and then calculate the total Ag Acres 
    #arcpy.AddMessage("build Table...")
    path,filename = os.path.split(outScnTable)
    arcpy.CreateTable_management(path,filename)
    
    arcpy.AddField_management(outScnTable,"BMPname", "Text")
    arcpy.AddField_management(outScnTable,"BMP_IDname", "Text")
    arcpy.AddField_management(outScnTable,"BMP_ID", "Text")
    
    # Add core N fields
    # whole field
    arcpy.AddField_management(outScnTable, "opAcres", "FLOAT")
    arcpy.AddField_management(outScnTable, "DirectCost", "FLOAT")
    arcpy.AddField_management(outScnTable, "OpportunityCosts", "FLOAT") 

    # treated portion of field field    
    arcpy.AddField_management(outScnTable, "cropAcres", "float")
    arcpy.AddField_management(outScnTable, "pctWScropAcres", "float")

    arcpy.AddField_management(outScnTable, "cpNload" , "LONG")
    arcpy.AddField_management(outScnTable, "cpNLoadReduced", "LONG")
    arcpy.AddField_management(outScnTable, "cpWSNLoadPct", "double")    
    
    arcpy.AddField_management(outScnTable, "TotalCost", "FLOAT")
    arcpy.AddField_management(outScnTable, "ReducedCostLB", "FLOAT")




def updateSummaryTable(outScnTable,bmpTable,bmpFields,CPname,CP_IDname):
    # Add the BMP records to the Scenario Summary Table, there will be records
    # for each of the selected practices for the chosen BMP feature classes
    arcpy.AddMessage("   summarizing %s practices..." % CPname)
    
    # create a temporry table for this Practices records
    tempFile = "tempFile"
    path,sTab = os.path.split(outScnTable)
    arcpy.CreateTable_management(path,tempFile,outScnTable)
    theTemp = os.path.join(path,tempFile)
    
    insertFields = ["BMP_ID","opAcres","DirectCost","OpportunityCosts","cropAcres","pctWScropAcres","cpNload","cpNLoadReduced","cpWSNLoadPct","TotalCost","ReducedCostLB"]

    with arcpy.da.SearchCursor(bmpTable,bmpFields) as sCur:
        with arcpy.da.InsertCursor(theTemp,insertFields) as iCur:
            for row in sCur:
                iCur.insertRow(row)
                
    arcpy.CalculateField_management(theTemp,"BMPname","'%s'" % CPname, "PYTHON")
    arcpy.CalculateField_management(theTemp,"BMP_IDname","'%s'" % CP_IDname, "PYTHON")
    
    arcpy.Append_management(theTemp,outScnTable,"NO_TEST")
    
    arcpy.Delete_management(theTemp)
    del(theTemp,path,sTab,insertFields,sCur,iCur)



def reduceExcessFields(wsSummarybyField):
    # If the riparian catchment has over 200 acres of agricutural land (tile-drained land if STB),
    #  reduce the effective acres to 200 by multiplying cropAcres by 200 / total catchment acres
    arcpy.Statistics_analysis(wsSummarybyField, "wsStat", [["cropAcres","SUM"]], "riparianid")
    arcpy.JoinField_management(wsSummarybyField, "riparianid", "wsStat", "riparianid", "SUM_cropAcres")
    
    bigFlist = [row[0] for row in arcpy.da.SearchCursor("wsStat","riparianid", "SUM_cropAcres > 200")]

    if len(bigFlist) > 0:
        arcpy.AddMessage("    %s riparian catchments with contributing crop areas > 200 acres...reduced" % str(len(bigFlist)))

        arcpy.MakeFeatureLayer_management(wsSummarybyField, "bigFields", "SUM_cropAcres > 200")
        
        with arcpy.da.UpdateCursor("bigFields",["cropAcres","SUM_cropAcres"]) as uCur:
            for row in uCur:
                row[0] = row[0] * ( 200 / row[1] )
            
                uCur.updateRow(row)
                
        del(uCur, row)

    arcpy.Delete_management("wsStat")    
    arcpy.Delete_management("bigFields")    
    del(bigFlist)
    


def addNPRedct(outFGDB, inFBnd, inFB_NPTable, BMPname, BMPwtrshed, BMP_Nfactor, BMP_Pfactor, tileTable):
    # A dictionary for extracting feature class identifier by practice
    FIDdict = {'NRW':'SiteID','PND':'SiteID','BIO':'pointid','CBS':'FBndID','STB':'riparianid','RIB':'riparianid','GWW':'FBndID'}

    # calculate total watershed N Load by field
    wsTotalNLoad = 0
    values = [row[0] for row in arcpy.da.SearchCursor(inFB_NPTable, "wsNLoad")]
    for NLoad in values: 
        if NLoad is not None:
            wsTotalNLoad = wsTotalNLoad + NLoad
 
    # intersect the Practice Watershed with the FBlayer to identify fields in AOI
    #  join with Nutrient table to acquire general N load info, then build the rest
    wsSummarybyField = os.path.join(outFGDB,"%s_WSSumrybyField" % BMPname)
    WSnutSummary  = os.path.join(outFGDB,"%s_WSnutrientSummary" % BMPname)
 
    # Create the field boundary feature layer (FBlayer) that will be investigated to extract 
    #  field N load data. For riparian practices segregate by tile drainage
    #    - Saturated Buffers (STB) use only tile-drained fields
    if BMPname == 'STB':
        arcpy.AddMessage('    Tiled drained only')
        arcpy.CopyFeatures_management(inFBnd, "FBdrained")
        arcpy.JoinField_management("FBdrained", "FBndID", tileTable, "FBndID", "Drained")
        arcpy.MakeFeatureLayer_management("FBdrained", "FBlayer", " isAG > 0 and Drained = 'YES' ")
    else:
        arcpy.MakeFeatureLayer_management(inFBnd, "FBlayer", "isAG > 0")

    # Intersect the practice watersheds and FBlayer
    arcpy.Intersect_analysis(["FBlayer", BMPwtrshed], wsSummarybyField)   
    jFields = ["GenLU","CropRotatn","CornYrs","N_6Yrs","Nrate","Nconc", "NloadAc","wsNLoad"]
    arcpy.JoinField_management(wsSummarybyField, "FBndID", inFB_NPTable,"FBndID", jFields)
    
 
    # Add Practice reduction fields and calculate
    cAcres = "cropAcres"
    pctWScAcres = "pctWScropAcres"
    cpN_Load = "cpNload" 
    cpN_Reduced = "cpNLoadReduced"
    pctWSNLoad = "cpWSNLoadPct"
    arcpy.AddField_management(wsSummarybyField, cAcres, "float")
    arcpy.AddField_management(wsSummarybyField, pctWScAcres, "float")

    arcpy.AddField_management(wsSummarybyField, cpN_Load, "LONG")
    arcpy.AddField_management(wsSummarybyField, cpN_Reduced, "LONG")
    arcpy.AddField_management(wsSummarybyField, pctWSNLoad, "double")
    
    arcpy.CalculateField_management(wsSummarybyField, cAcres, "!Shape_Area! * 0.000247", "PYTHON")
    # Now, with the copAcres calculated...
    # If riparian, check for and reduce large contributing areas affecg on load and costs
    if BMPname == 'STB':
        reduceExcessFields(wsSummarybyField)
    elif BMPname == 'RIB':
        reduceExcessFields(wsSummarybyField)
    
    arcpy.CalculateField_management(wsSummarybyField, cpN_Load, "!NloadAc! * !cropAcres!", "PYTHON") # the N Load is only for the affected acres
    arcpy.CalculateField_management(wsSummarybyField, cpN_Reduced, "!cpNload! * %s" % BMP_Nfactor, "PYTHON") # the N Load is only for the affected acres
    arcpy.CalculateField_management(wsSummarybyField, pctWSNLoad, "!cpNLoadReduced! / %s * 100.0" % float(wsTotalNLoad), "PYTHON") # the percent of total N load for the affected acres


    # Summarize nutrients by practice using by the appropriate feature identifier [FIDdict.get(BMPname)] (DISSOLVE)
    #  to create the full practice watersheds...some watersheds may be split by other non-ag features (roads) - MULTI_PART 
    statFields="cropAcres SUM;pctWScropAcres SUM;Nrate MEAN;Nconc MEAN;NloadAc MEAN;cpNload SUM;cpNLoadReduced SUM;cpWSNLoadPct SUM"
    arcpy.Dissolve_management(wsSummarybyField, WSnutSummary, FIDdict.get(BMPname), statFields, "MULTI_PART", "DISSOLVE_LINES")
    
    # Cleanup
    arcpy.Delete_management("FBlayer") 
    arcpy.Delete_management("FBdrained") 
    del(statFields,cAcres,pctWScAcres,cpN_Load,cpN_Reduced,pctWSNLoad)
    
    return(WSnutSummary)
    
    

def smrzOCosts(BMP, BMPname, BMPsoils, rRate):
    # a routine to create area-weighted Productivity Idx i.e. OCprodIdx
    #    on a BMP's removal polygon
    
    FIDdict = {'NRW':'SiteID','PND':'SiteID','BIO':'pointid','CBS':'FBndID','STB':'riparianid','RIB':'riparianid','GWW':'FBndID'}
    
    oCostTable = "OCosts_%s" % BMPname

    # Area weight the Productivity Index (meters is OK)
    arcpy.AddField_management(BMPsoils, "wgtArea", "FLOAT")
    arcpy.CalculateField_management(BMPsoils, "wgtArea", "(!gridcode! * !Shape_Area!)", "PYTHON")

    # Then summarize on the feature identifier FID to get the area-weighted Productivity Index
    arcpy.Statistics_analysis(BMPsoils, oCostTable, "wgtArea SUM;Shape_Area SUM", FIDdict.get(BMPname))
    arcpy.AddField_management(oCostTable, "Acres", "FLOAT")
    arcpy.AddField_management(oCostTable, "meanPIdx", "SHORT")
    arcpy.AddField_management(oCostTable, "OpportunityCosts", "FLOAT")
    arcpy.CalculateField_management(oCostTable, "Acres", "(!SUM_Shape_Area! * 0.000247) ", "PYTHON")
    arcpy.CalculateField_management(oCostTable, "meanPIdx", "(!SUM_wgtArea! / !SUM_Shape_Area!)", "PYTHON")
    #arcpy.CalculateField_management(oCostTable, "OpportunityCosts", "((!meanPIdx! * !Acres!) * 2.72)", "PYTHON") #statewide IA avg. cost $2.72
    # arcpy.CalculateField_management(oCostTable, "OpportunityCosts", "((!meanPIdx! * !Acres!) * 2.87)", "PYTHON") #2.87 is area-weighted avg $/CSR2 for MLRA 103 IA
    arcpy.CalculateField_management(oCostTable, "OpportunityCosts", "((!meanPIdx! * !Acres!) * %s)" % (rRate), "PYTHON")
    del(FIDdict)
    
    return(oCostTable)




def extractOpportunityCosts(inHUC, inFBnd, inFB_NPTable, gSSURGO, outScnTable, NRW, BIO, DWM, CBS, STB, RIB, GWW, inFlowDir, inFlowAcc, AgAcres, wsTotalNLoad, tileTable):

    # need the cell size
    # -------------------------------------------------------------
    cellsize = int(arcpy.GetRasterProperties_management(inFlowDir, "CELLSIZEX").getOutput(0))
    arcpy.env.snapRaster = inFlowDir

    # Convert gSSURGO TO polygon, Iowa Corn suitability Rating (iacsr) for row crop
    #   else for isAG = 2 - grass, pasture, hay; OCprodIdx = OCprodIdx * .35 (state wide row crop to PGH multiplier)
    # -------------------------------------------------------------
    arcpy.RasterToPolygon_conversion(gSSURGO, "gSSrgo_poly", "NO_SIMPLIFY", "OCprodIdx")
    # Union with fb to find isAG distribution
    arcpy.Union_analysis([inFBnd,"gSSrgo_poly"], "gS_poly")
    # web service for Crop Reporting Districts get multiplier & O cost/ iacsr pt
    # Update Cursor...if isAG == 0, iacsr = 0; if isAG = 2, iacsr = iacsr * .35 (state wide row crop to PGH multiplier)
    with arcpy.da.UpdateCursor("gS_poly",["isAG","gridcode"], "isAG <> 1" ) as uCur:
        for row in uCur:
            if row[0] == 2:
                row[1] = row[1] * .35
            else:
                row[1] = 0
                
            uCur.updateRow(row)
                
    arcpy.Delete_management("gSSrgo_poly")
    del(uCur, row)


    # Process by BMP, if they are included...if discrete elements are selected, only they will be included
    # ----------------------------------------------------------------------------------------------------
         
    if NRW is not "":
        arcpy.AddMessage("processing Nutrient Removal Wetlands")

        NRWSummary = os.path.join(outFGDB,"NRW_practiceSummary")
        # Calculate Opportunity Costs by practice class
        # NRW Buffer and Wetland are removed from production..so Dissolve on SiteID for single polygon
        arcpy.Dissolve_management(NRW, NRWSummary,["SiteID"], "", "MULTI_PART", "DISSOLVE_LINES")         
        arcpy.Intersect_analysis([NRWSummary, "gS_poly"], "nrwSoils")
        NRWOCostsTable = smrzOCosts(NRW, 'NRW', "nrwSoils", rRate)
        
        # Calculate Direct Cost
        # Mean NRW: $806 / acres ($2020 IA)
        # Mean NRW: $1646 / acre ($2021 IA)
        # Mean NRW: $2854 / acre ($2024 IA)
        arcpy.AddField_management(NRWSummary, "opAcres", "FLOAT")
        arcpy.AddField_management(NRWSummary, "DirectCost", "FLOAT")
        arcpy.CalculateField_management(NRWSummary, "opAcres", "(!Shape_Area! * 0.000247)", "PYTHON")
        arcpy.CalculateField_management(NRWSummary, "DirectCost", "(!opAcres! * 2854)", "PYTHON")
        
        # Add the opportunity costs
        arcpy.JoinField_management(NRWSummary, "siteID", NRWOCostsTable, "SiteID", ["meanPIdx","OpportunityCosts"])     
        
        # Watersheds
        # NRW Watershed as area treated
        arcpy.AddMessage("   NRW Watersheds...")
        nwrWtrSheds = "nwrWtrSheds"
        path,filename = os.path.split(NRW)
        NWRdrain = os.path.join(path,'NRWDrainageAreas' + inHUC)
        arcpy.MakeFeatureLayer_management(NWRdrain, "drainLyr")
        arcpy.MakeFeatureLayer_management(NRW, "poolLyr", "CoverType = 'Wetland'")
        arcpy.SelectLayerByLocation_management("drainLyr", "INTERSECT", "poolLyr", "", "NEW_SELECTION")
        arcpy.CopyFeatures_management("drainLyr", nwrWtrSheds)
        
        # Calculate the watershed N load and reductions via the addNPRedct modeule
        #  add N reduct field: NRW reduction 52%, remaining 48% - .48
        #      P reduct field: NRW reduction 0%, remaining 100% - 0.0
        WSnutSummary = addNPRedct(outFGDB, inFBnd, inFB_NPTable, 'NRW', nwrWtrSheds, 0.52, 0.0, tileTable)
        arcpy.CalculateField_management(WSnutSummary, "SUM_pctWScropAcres", "(!SUM_cropAcres! / %s) * 100.0" % int(AgAcres), "PYTHON")   
        #arcpy.CalculateField_management(WSnutSummary, "SUM_cpWSNLoadPct", "(!SUM_cpNLoadReduced! / %s) * 100.0" % float(wsTotalNLoad), "PYTHON")   
        
        # Add the watershed nutrient info to the practice summary
        jFields = ["SUM_cropAcres","SUM_pctWScropAcres","MEAN_Nrate","MEAN_Nconc","SUM_cpNload","MEAN_cpNloadAcre","SUM_cpNLoadReduced","SUM_cpWSNLoadPct"]
        arcpy.JoinField_management(NRWSummary, "siteID", WSnutSummary, "SiteID", jFields) 
        
        # Calculate N load reduction costs
        arcpy.AddField_management(NRWSummary, "TotalCost", "FLOAT")
        arcpy.AddField_management(NRWSummary, "ReducedCostLB", "FLOAT")
        arcpy.CalculateField_management(NRWSummary,"TotalCost", "!DirectCost! + !OpportunityCosts!","PYTHON")
        arcpy.CalculateField_management(NRWSummary,"ReducedCostLB", "!TotalCost! / !SUM_cpNLoadReduced!","PYTHON")
        
        # update summary table
        nrwFields = ["SiteID","opAcres","DirectCost","OpportunityCosts","SUM_cropAcres","SUM_pctWScropAcres","SUM_cpNload","SUM_cpNLoadReduced","SUM_cpWSNLoadPct","TotalCost","ReducedCostLB"]
        updateSummaryTable(outScnTable,NRWSummary,nrwFields,'NRW','SiteID')
           
        # Cleanup        
        arcpy.Delete_management("drainLyr")
        arcpy.Delete_management("nrwSoils")
        arcpy.Delete_management("poolLyr")
        arcpy.Delete_management(nwrWtrSheds)
        arcpy.Delete_management(NRWOCostsTable)
        
        del(nwrWtrSheds,NRWOCostsTable,path,filename,NWRdrain,jFields)
    
        
#    if PND is not "":
#        arcpy.AddMessage("processing Ponds")
#        # NRW Watershed reports area treated
#        #  add N reduct field: PND reduction 52%, remaining 48% - .48
#        #      P reduct field: PND reduction 85%, remaining 15% - .15
#        addNPRedct(outFGDB, inFBnd, outScnTable, PND, 0.48, 0.15)
#
#        # Calculate Opportunity Costs by practice class
#        # NRW Buffer and Wetland are removed from production..so Dissolve on SiteID for single polygon
#        #arcpy.Dissolve_management(NRW, "nrwDissolve",["SiteID"], "", "SINGLE_PART", "DISSOLVE_LINES")
#        arcpy.Dissolve_management(PND, "pndDissolve",["SiteID"], "", "MULTI_PART", "DISSOLVE_LINES")
#         
#        arcpy.Intersect_analysis(["pndDissolve", "gS_poly"], "nrwSoils")
#        NRWOCostsTable = smrzOCosts(PND, 'NRW', "nrwSoils")
#        
#        # Calculate Direct Cost
#        # Mean NRW: $9,793/acres Wetland only + $2,300 hardware
#        arcpy.AddField_management("pndDissolve", "opAcres", "FLOAT")
#        arcpy.AddField_management("pndDissolve", "DirectCost", "FLOAT")
#        arcpy.CalculateField_management("pndDissolve", "opAcres", "(!Shape_Area! * 0.000247)", "PYTHON")
#        arcpy.CalculateField_management("pndDissolve", "DirectCost", "((!opAcres! * 9793) + 2300)", "PYTHON")
#     
#        # Add the opportunity costs
#        arcpy.JoinField_management("pndDissolve", "siteID", PNDOCostsTable, "SiteID", ["meanPIdx"])
        
        
    if BIO is not "":
        arcpy.AddMessage("processing Bioreactors")

        BIOSummary = os.path.join(outFGDB,"BIO_practiceSummary")
        arcpy.CopyFeatures_management(BIO, BIOSummary)
        arcpy.DeleteIdentical_management(BIOSummary, ["pointid"])
        
        # Calculate opportunity costs from gSSURGO
        arcpy.Intersect_analysis([BIOSummary, "gS_poly"], "bioSoils")
        BIOOCostsTable = smrzOCosts(BIOSummary, 'BIO', "bioSoils", rRate)
        
        # Calculate Direct Cost
        # Mean BIO: $715 per Acre removed bioreactor (50 ac drainage) 2020 IA
        # Mean BIO: $2207 per Acre removed bioreactor (50 ac drainage) 2021 IA
        arcpy.AddField_management(BIOSummary, "opAcres", "FLOAT")
        arcpy.AddField_management(BIOSummary, "DirectCost", "FLOAT")
        arcpy.CalculateField_management(BIOSummary, "opAcres", "(!Shape_Area! * 0.000247)", "PYTHON")
        arcpy.CalculateField_management(BIOSummary, "DirectCost", "!opAcres! * 2207", "PYTHON")
        
        # Add the opportunity costs
        arcpy.JoinField_management(BIOSummary, "pointid", BIOOCostsTable, "pointid", ["meanPIdx","OpportunityCosts"])

        # create the watershed, recreate FAcc domain, convert to polyline & snap points
        arcpy.AddMessage("   BIO Watersheds...")
        arcpy.env.snapRaster = inFlowDir
        rAcres = 4046 / (cellsize * cellsize) 
        snapMask = Con(inFlowAcc, 1, "", "Value >= %s and Value <= %s" % (str(rAcres * 20), str(rAcres * 100)))
        snapMask.save("snapMsk")
        arcpy.RasterToPolyline_conversion(snapMask, "snapLine", "NODATA", 0, "NO_SIMPLIFY", "VALUE")
        
        arcpy.FeatureToPoint_management(BIOSummary, "bPts", "INSIDE")
        arcpy.Snap_edit("bPts", [["snapLine", "EDGE", "100 meters"]])
        arcpy.PointToRaster_conversion("bPts","pointid","bPtsRas")
        
        arcpy.AddMessage("   BIO Watersheds create")
        bioWS = "in_memory\\bioWS"
        bioWS = Watershed(inFlowDir, "bPtsRas")
        #arcpy.AddMessage("   BIO Watersheds VAT")
        arcpy.BuildRasterAttributeTable_management(bioWS)
        
        inWtrShed = "inWtrSheds" 
        bioWtrShed = "bioWtrSheds" 
        arcpy.RasterToPolygon_conversion(bioWS, inWtrShed, "NO_SIMPLIFY", "Value")
        arcpy.Dissolve_management(inWtrShed, bioWtrShed,["gridcode"], "", "MULTI_PART", "DISSOLVE_LINES")
        arcpy.JoinField_management(bioWtrShed, "gridcode", "bPts", "pointid", ["pointid","FBndID"])
        
        # Calculate the watershed N load and reductions via the addNPRedct modeule
        #  add N reduct field: BIO reduction 43%, remaining 57% - 0.43
        #      P reduct field: BIO reduction 0%, remaining 100% - 0.0
        #addNPRedct(inFBnd, outScnTable, BIO, 0.57, 1.0)
        WSnutSummary = addNPRedct(outFGDB, inFBnd, inFB_NPTable, 'BIO', bioWtrShed,  0.43, 0.0, tileTable)
        # Delete those WS features with either no tile-drained land (NULL crop acres) or less than 20 ac tile drained 
        arcpy.MakeFeatureLayer_management(WSnutSummary, "LT20", "SUM_cropAcres < 20 OR SUM_cropAcres IS NULL")
        arcpy.DeleteFeatures_management("LT20")
        arcpy.Delete_management("LT20")

        arcpy.CalculateField_management(WSnutSummary, "SUM_pctWScropAcres", "(!SUM_cropAcres! / %s) * 100.0" % int(AgAcres), "PYTHON")   

        # Add the watershed nutrient info to the practice summary
        arcpy.AddMessage("next...jon WSnutSummary to BIOSummary")
        jFields = ["SUM_cropAcres","SUM_pctWScropAcres","MEAN_Nrate","MEAN_Nconc","SUM_cpNload","MEAN_cpNloadAcre","SUM_cpNLoadReduced","SUM_cpWSNLoadPct"]
        arcpy.JoinField_management(BIOSummary, "pointid", WSnutSummary, "pointid", jFields) 
        
        # Delete those WS features with eith no tile-drained land (NULL crop acres) or less than 20 ac tile drained 
        arcpy.MakeFeatureLayer_management(BIOSummary, "LT20", "SUM_cropAcres < 20 OR SUM_cropAcres IS NULL")
        arcpy.DeleteFeatures_management("LT20")
        arcpy.Delete_management("LT20")
        
        # Calculate N load reduction costs
        arcpy.AddField_management(BIOSummary, "TotalCost", "FLOAT")
        arcpy.AddField_management(BIOSummary, "ReducedCostLB", "FLOAT")
        arcpy.CalculateField_management(BIOSummary,"TotalCost", "!DirectCost! + !OpportunityCosts!","PYTHON")
        arcpy.CalculateField_management(BIOSummary,"ReducedCostLB", "!TotalCost! / !SUM_cpNLoadReduced!","PYTHON")
        
        # update summary table
        bioFields = ["pointid","opAcres","DirectCost","OpportunityCosts","SUM_cropAcres","SUM_pctWScropAcres","SUM_cpNload","SUM_cpNLoadReduced","SUM_cpWSNLoadPct","TotalCost","ReducedCostLB"]
        updateSummaryTable(outScnTable,BIOSummary,bioFields,'BIO','pointid')
           
        # cleanup
        arcpy.Delete_management("bioSoils")
        arcpy.Delete_management("bPts")
        arcpy.Delete_management("bPtsRas")
        arcpy.Delete_management("snapLine")
        arcpy.Delete_management(bioWS)
        arcpy.Delete_management(snapMask)
        arcpy.Delete_management(inWtrShed)
        arcpy.Delete_management(bioWtrShed)
        arcpy.Delete_management(BIOOCostsTable)
        
        del[rAcres,snapMask,bioWS,inWtrShed,bioWtrShed,BIOOCostsTable]

        
    if CBS is not "":
        arcpy.AddMessage("processing Contour Buffer Strips")

        CBSSummary = os.path.join(outFGDB,"CBS_practiceSummary")

        # Calculate opportunity costs from gSSURGO
        arcpy.Dissolve_management(CBS, CBSSummary, "FBndID")
        arcpy.Intersect_analysis([CBSSummary, "gS_poly"], "cbsSoils")
        CBSOCostsTable = smrzOCosts(CBSSummary, 'CBS', "cbsSoils", rRate)
        
        # Calculate Direct Cost
        # Mean CBS: $49 per acres ($2020 IA)
        # Mean CBS: $29 per acres ($2021 IA)
        # Mean CBS: $41 per acres ($2024 IA)
        arcpy.AddField_management(CBSSummary, "opAcres", "FLOAT")
        arcpy.AddField_management(CBSSummary, "DirectCost", "FLOAT")
        arcpy.CalculateField_management(CBSSummary, "opAcres", "(!Shape_Area! * 0.000247)", "PYTHON")
        arcpy.CalculateField_management(CBSSummary, "DirectCost", "!opAcres! * 41", "PYTHON")
        
        # Add the opportunity costs
        arcpy.JoinField_management(CBSSummary, "FBndID", CBSOCostsTable, "FBndID", ["meanPIdx","OpportunityCosts"])

        # create the watershed
        arcpy.AddMessage("   CBS Watersheds...")
        arcpy.env.snapRaster = inFlowDir
        theOID = arcpy.Describe(CBSSummary).OIDFieldName
        arcpy.FeatureToRaster_conversion(CBSSummary, theOID, "cbsRaster", cellsize)
             
        cbsWSras = "in_memory\\cbsWShed"
        cbsWSras = Watershed(inFlowDir, "cbsRaster", "Value")

        #arcpy.AddMessage('built VAT')
        arcpy.BuildRasterAttributeTable_management(cbsWSras)    
        #arcpy.AddMessage('joined')
        arcpy.JoinField_management(cbsWSras, "Value", CBSSummary, theOID, ["FBndID"])
        
        cbsWtrShed = "cbsWtrSheds" 
        arcpy.RasterToPolygon_conversion(cbsWSras, cbsWtrShed, "NO_SIMPLIFY", "FBndID")
                
        #  add N reduct field: CBS reduction 91%, remaining 9% - 0.91
        #      P reduct field: CBS reduction 58%, remaining 42% - 0.58
        WSnutSummary = addNPRedct(outFGDB, inFBnd, inFB_NPTable, 'CBS', cbsWtrShed,  0.91, 0.58, tileTable)
        arcpy.CalculateField_management(WSnutSummary, "SUM_pctWScropAcres", "(!SUM_cropAcres! / %s) * 100.0" % int(AgAcres), "PYTHON")   

        # Add the watershed nutrient info to the practice summaey
        jFields = ["SUM_cropAcres","SUM_pctWScropAcres","MEAN_Nrate","MEAN_Nconc","SUM_cpNload","MEAN_cpNloadAcre","SUM_cpNLoadReduced","SUM_cpWSNLoadPct"]
        arcpy.JoinField_management(CBSSummary, "FBndID", WSnutSummary, "FBndID", jFields) 
        
        # Calculate N load reduction costs
        arcpy.AddField_management(CBSSummary, "TotalCost", "FLOAT")
        arcpy.AddField_management(CBSSummary, "ReducedCostLB", "FLOAT")
        arcpy.CalculateField_management(CBSSummary,"TotalCost", "!DirectCost! + !OpportunityCosts!","PYTHON")
        arcpy.CalculateField_management(CBSSummary,"ReducedCostLB", "!TotalCost! / !SUM_cpNLoadReduced!","PYTHON")
      
        # update summary table
        cbsFields = ["FBndID","opAcres","DirectCost","OpportunityCosts","SUM_cropAcres","SUM_pctWScropAcres","SUM_cpNload","SUM_cpNLoadReduced","SUM_cpWSNLoadPct","TotalCost","ReducedCostLB"]
        updateSummaryTable(outScnTable,CBSSummary,cbsFields,'CBS','FBndID')

        arcpy.Delete_management("cbsSoils")
        arcpy.Delete_management("cbsRaster")
        arcpy.Delete_management(cbsWtrShed)
        arcpy.Delete_management(cbsWSras)
        arcpy.Delete_management(CBSOCostsTable)
        
        del[cbsWtrShed,cbsWSras,CBSOCostsTable]


    if STB is not "":
        arcpy.AddMessage("processing Riparian Saturated Buffers")
        STBSummary = os.path.join(outFGDB,"STB_practiceSummary")

        # Calculate Opportunity Costs by practice class
        # work around joined tables for riparianid -- 'RAP070802010202_riparianid'
        #...the tool expects the RAP feature class has been joined to the satuated buffer table
        path,filename = os.path.split(STB)
        arcpy.CopyFeatures_management(STB, STBSummary)
        arcpy.AddField_management(STBSummary, "riparianid", "TEXT")
        arcpy.CalculateField_management(STBSummary, "riparianid", "!RAP%s_riparianid!" % inHUC, "PYTHON")
        
        # remove riparian catchments LE 20 acres
        #arcpy.JoinField_management(STBSummary, "riparianid", "SaturatedBuffer%s" % inHUC, "riparianid", ["acres"])
        #arcpy.MakeFeatureLayer_management(STBSummary, "stbLyr", "acres < 20")
        #arcpy.DeleteFeatures_management("stbLyr")
        #arcpy.Delete_management("stbLyr")

        # Opportunity Costs table - uses OCprodIdx from gSSURGO        
        arcpy.Intersect_analysis([STBSummary, "gS_poly"], "stbSoils")
        STBOCostsTable = smrzOCosts(STB, 'STB', "stbSoils", rRate)
        
        # Calculate Direct Cost
        # Direct Costs: $287/1000ft * 0.82021 (250m/1000ft) = 235.40 ($2020 IA)
        # Direct Costs: $359/1000ft * 0.82021 (250m/1000ft) = 294.46 ($2021 IA)
        arcpy.AddField_management(STBSummary, "opAcres", "FLOAT")
        arcpy.AddField_management(STBSummary, "DirectCost", "FLOAT")
        arcpy.CalculateField_management(STBSummary, "opAcres", "(!Shape_Area! * 0.000247)", "PYTHON")
        # this is for a standard 250m riaparian stream segment...should adjust for variations in reach lengths
        arcpy.CalculateField_management(STBSummary, "DirectCost", "(!opAcres! * 294.46)", "PYTHON")
        
        # Add the opportunity costs; 1) as calculated with standard buffer width, and 2) adjusted to recommended buffer width
        arcpy.JoinField_management(STBSummary, "riparianid", STBOCostsTable, "riparianid", ["meanPIdx","OpportunityCosts"])
        ripFunc = os.path.join(path, 'RiparianFunction' + inHUC)
        arcpy.JoinField_management(STBSummary,  "riparianid", ripFunc, "riparianid", ["BuffWidth"])
        arcpy.AddField_management(STBSummary, "recBuffWidth", "FLOAT")
        arcpy.AddField_management(STBSummary, "adjOCosts", "FLOAT")
        arcpy.CalculateField_management(STBSummary, "recBuffWidth", "!BuffWidth!", "PYTHON")
        arcpy.CalculateField_management(STBSummary, "adjOCosts", "(!recBuffWidth! / 15) * !OpportunityCosts!", "PYTHON")
        
        keepList = ['riparianid','opAcres','DirectCost','meanPIdx','OpportunityCosts','adjOCosts','recBuffWidth']
        DeleteFields(STBSummary, keepList)
      
        # Watersheds
        arcpy.AddMessage("   STB Watersheds...")
        ripCtch = os.path.join(path, 'RiparianCatchments' + inHUC)
        arcpy.MakeFeatureLayer_management(ripCtch, "RCtchLyr")
        arcpy.AddJoin_management("RCtchLyr", "riparianid", STBSummary, "riparianid", "KEEP_COMMON")
        arcpy.CopyFeatures_management("RCtchLyr", "stbWtrSheds")
        arcpy.RemoveJoin_management("RCtchLyr")
        
        arcpy.AddField_management("stbWtrSheds", "riparianid", "TEXT")
        arcpy.CalculateField_management("stbWtrSheds", "riparianid", "!RiparianCatchments%s_riparianid!" % inHUC, "PYTHON")
        keepList = ['riparianid']
        DeleteFields("stbWtrSheds", keepList)
        
        # Add the watershed nutrient info to the practice summaey
        #  add N reduct field: STB reduction 50%, remaining 50% - 0.50
        #      P reduct field: STB reduction 0%, remaining 100% - 0.0
        WSnutSummary = addNPRedct(outFGDB, inFBnd, inFB_NPTable, 'STB', "stbWtrSheds",  0.50, 0.0, tileTable)
        
        # Delete those WS features with either no tile-drained land (NULL crop acres) or less than 20 ac tile drained 
        arcpy.MakeFeatureLayer_management(WSnutSummary, "noTD", " SUM_cropAcres IS NULL OR SUM_cropAcres < 20 ")
        arcpy.DeleteFeatures_management("noTD")
        arcpy.CalculateField_management(WSnutSummary, "SUM_pctWScropAcres", "(!SUM_cropAcres! / %s) * 100.0" % int(AgAcres), "PYTHON")   

        # Add the Nutrient info and calculate load costs
        jFields = ["SUM_cropAcres","SUM_pctWScropAcres","MEAN_Nrate","MEAN_Nconc","SUM_cpNload","MEAN_cpNloadAcre","SUM_cpNLoadReduced","SUM_cpWSNLoadPct"]
        arcpy.JoinField_management(STBSummary, "riparianid", WSnutSummary, "riparianid", jFields) 
        
        # Delete those WS features with eith no tile-drained land (NULL crop acres) or less than 20 ac tile drained 
        arcpy.MakeFeatureLayer_management(STBSummary, "noTD", " SUM_cropAcres IS NULL OR SUM_cropAcres < 20 ")
        arcpy.DeleteFeatures_management("noTD")
        
        # Calculate N load reduction costs
        arcpy.AddField_management(STBSummary, "TotalCost", "FLOAT")
        arcpy.AddField_management(STBSummary, "ReducedCostLB", "FLOAT")
        arcpy.CalculateField_management(STBSummary,"TotalCost", "!DirectCost! + !OpportunityCosts!","PYTHON")
        arcpy.CalculateField_management(STBSummary,"ReducedCostLB", "!TotalCost! / !SUM_cpNLoadReduced!","PYTHON")

         # update summary table
        stbFields = ["riparianid","opAcres","DirectCost","OpportunityCosts","SUM_cropAcres","SUM_pctWScropAcres","SUM_cpNload","SUM_cpNLoadReduced","SUM_cpWSNLoadPct","TotalCost","ReducedCostLB"]
        updateSummaryTable(outScnTable,STBSummary,stbFields,'STB','riparianid')
       
        arcpy.Delete_management("RCtchLyr")
        arcpy.Delete_management("stbSoils")
        arcpy.Delete_management("stbWtrSheds")
        arcpy.Delete_management(STBOCostsTable)
         
         
    if RIB is not "":
        RIBSummary = os.path.join(outFGDB,"RIB_practiceSummary")
        
        arcpy.AddMessage("processing Riparian Buffers")

        # Calculate Opportunity Costs by practice class
        # work around joined tables for riparianid
        path,filename = os.path.split(RIB)
        arcpy.CopyFeatures_management(RIB, RIBSummary)
        arcpy.AddField_management(RIBSummary, "riparianid", "TEXT")
        arcpy.CalculateField_management(RIBSummary, "riparianid", "!RAP%s_riparianid!" % inHUC, "PYTHON")
        
        # Opportunity Costs table - uses OCprodIdx from gSSURGO        
        arcpy.Intersect_analysis([RIBSummary, "gS_poly"], "ribSoils")
        RIBOCostsTable = smrzOCosts(RIB, 'RIB', "ribSoils", rRate)
        
        # Calculate Direct Cost
        # Direct Costs: $61 per acre (Multi-species buffer) ($2020 IA)
        # Direct Costs: $78 per acre (Multi-species buffer) ($2021 IA)
        # Direct Costs: $97 per acre (Multi-species buffer) ($2024 IA)
        arcpy.AddField_management(RIBSummary, "opAcres", "FLOAT")
        arcpy.AddField_management(RIBSummary, "DirectCost", "FLOAT")
        arcpy.CalculateField_management(RIBSummary, "opAcres", "(!Shape_Area! * 0.000247)", "PYTHON")
        arcpy.CalculateField_management(RIBSummary, "DirectCost", "(!opAcres! * 97)", "PYTHON")
        
        # Add the opportunity costs; 1) as calculated with standard buffer width, and 2) adjusted to recommended buffer width
        arcpy.JoinField_management(RIBSummary, "riparianid", RIBOCostsTable, "riparianid", ["meanPIdx","OpportunityCosts"])
        ripFunc = os.path.join(path, 'RiparianFunction' + inHUC)
        arcpy.JoinField_management(RIBSummary,  "riparianid", ripFunc, "riparianid", ["BuffWidth"])
        arcpy.AddField_management(RIBSummary, "recBuffWidth", "FLOAT")
        arcpy.AddField_management(RIBSummary, "adjOCosts", "FLOAT")
        arcpy.CalculateField_management(RIBSummary, "recBuffWidth", "!BuffWidth!", "PYTHON")
        arcpy.CalculateField_management(RIBSummary, "adjOCosts", "(!recBuffWidth! / 15) * !OpportunityCosts!", "PYTHON")
        
        keepList = ['riparianid','opAcres','DirectCost','meanPIdx','OpportunityCosts','adjOCosts','recBuffWidth']
        DeleteFields(RIBSummary, keepList)
      
        # Watersheds
        arcpy.AddMessage("   RIB Watersheds...")
        ripCtch = os.path.join(path, 'RiparianCatchments' + inHUC)
        arcpy.MakeFeatureLayer_management(ripCtch, "RCtchLyr")
        arcpy.AddJoin_management("RCtchLyr", "riparianid", RIBSummary, "riparianid", "KEEP_COMMON")
        arcpy.CopyFeatures_management("RCtchLyr", "ribWtrSheds")
        arcpy.RemoveJoin_management("RCtchLyr")
        
        arcpy.AddField_management("ribWtrSheds", "riparianid", "TEXT")
        arcpy.CalculateField_management("ribWtrSheds", "riparianid", "!RiparianCatchments%s_riparianid!" % inHUC, "PYTHON")
        keepList = ['riparianid']
        DeleteFields("ribWtrSheds", keepList)

        #  add N reduct field: RIB reduction 91%, remaining 9% - 0.91
        #      P reduct field: RIB reduction 58%, remaining 42% - 0.58
        WSnutSummary = addNPRedct(outFGDB, inFBnd, inFB_NPTable, 'RIB', "ribWtrSheds",  0.91, 0.58, tileTable)
        arcpy.CalculateField_management(WSnutSummary, "SUM_pctWScropAcres", "(!SUM_cropAcres! / %s) * 100.0" % int(AgAcres), "PYTHON")   

        # Add the Nutrient info and calculate load costs
        jFields = ["SUM_cropAcres","SUM_pctWScropAcres","MEAN_Nrate","MEAN_Nconc","SUM_cpNload","MEAN_cpNloadAcre","SUM_cpNLoadReduced","SUM_cpWSNLoadPct"]
        arcpy.JoinField_management(RIBSummary, "riparianid", WSnutSummary, "riparianid", jFields) 
        
        # Calculate N load reduction costs
        arcpy.AddField_management(RIBSummary, "TotalCost", "FLOAT")
        arcpy.AddField_management(RIBSummary, "ReducedCostLB", "FLOAT")
        arcpy.CalculateField_management(RIBSummary,"TotalCost", "!DirectCost! + !OpportunityCosts!","PYTHON")
        arcpy.CalculateField_management(RIBSummary,"ReducedCostLB", "!TotalCost! / !SUM_cpNLoadReduced!","PYTHON")

        # update summary table
        ribFields = ["riparianid","opAcres","DirectCost","OpportunityCosts","SUM_cropAcres","SUM_pctWScropAcres","SUM_cpNload","SUM_cpNLoadReduced","SUM_cpWSNLoadPct","TotalCost","ReducedCostLB"]
        updateSummaryTable(outScnTable,RIBSummary,ribFields,'RIB','riparianid')

        # Cleanup
        arcpy.Delete_management("RCtchLyr")
        arcpy.Delete_management("ribSoils")
        arcpy.Delete_management("ribWtrSheds")
        arcpy.Delete_management(RIBOCostsTable)
        del (RIBOCostsTable, keepList,ripCtch)

       
    if GWW is not "":
        arcpy.AddMessage("processing Grass Waterways")
        GWWSummary = os.path.join(outFGDB,"GWW_practiceSummary")
        
        # Assuming  30FT (10M) standard width
        arcpy.Buffer_analysis(GWW, GWWSummary, "10 meters", "FULL", "FLAT", "LIST", "FBndID")
        arcpy.Intersect_analysis([GWWSummary, "gS_poly"], "gwwSoils")
        GWWOCostsTable = smrzOCosts(GWWSummary, 'GWW', "gwwSoils", rRate)
        
        # Calculate Direct Cost
        # Mean GWW: $93 per acre ($2020 and $2021 IA)
        # Mean GWW: $163 per acre ($2024 IA)
        arcpy.AddField_management(GWWSummary, "opAcres", "FLOAT")
        arcpy.AddField_management(GWWSummary, "DirectCost", "FLOAT")
        arcpy.CalculateField_management(GWWSummary, "opAcres", "(!Shape_Area! * 0.000247)", "PYTHON")
        arcpy.CalculateField_management(GWWSummary, "DirectCost", "!opAcres! * 163", "PYTHON")
        
        # Add the opportunity costs
        arcpy.JoinField_management(GWWSummary, "FBndID", GWWOCostsTable, "FBndID", ["meanPIdx","OpportunityCosts"])
        
        # Calculate N load reduction final costs
        arcpy.AddField_management(GWWSummary, "TotalCost", "FLOAT")
        arcpy.CalculateField_management(GWWSummary,"TotalCost", "!DirectCost! + !OpportunityCosts!","PYTHON")

        # cleanup
        del (GWWOCostsTable)

        
    if DWM is not "":
        arcpy.AddMessage("processing Drainage Water Manangement locations")
        
        DWMSummary = os.path.join(outFGDB,"DWM_practiceSummary")
        arcpy.CopyFeatures_management(DWM, DWMSummary)
        
        #arcpy.AddMessage("processing Drainage Water Management")
        #  add N reduct field: DWM reduction 33%, remaining 67% - .67
        #      P reduct field: DWM reduction 0%, remaining 100% - 1.0
        # By Field practices have no Opportunity costs
        
        # Calculate Direct Cost
        arcpy.AddField_management(DWMSummary, "opAcres", "FLOAT")
        arcpy.AddField_management(DWMSummary, "DirectCost", "FLOAT")
        arcpy.AddField_management(DWMSummary, "OpportunityCosts", "FLOAT")
        arcpy.CalculateField_management(DWMSummary, "opAcres", "0", "PYTHON")
        arcpy.CalculateField_management(DWMSummary, "OpportunityCosts", "0", "PYTHON")
        
        # the pre-calculated field N load information fromm the nutrient table
        jFields = ["GenLU","CropRotatn","CornYrs","N_6Yrs","Nrate","Nconc", "NloadAc","wsNLoad"]
        arcpy.JoinField_management(DWMSummary, "FBndID", inFB_NPTable,"FBndID", jFields)
        
        # Add and calculate the the Practice reduction fields...no watersheds here
        arcpy.AddField_management(DWMSummary, "cropAcres", "float")
        arcpy.AddField_management(DWMSummary, "pctWScropAcres", "float")
        arcpy.AddField_management(DWMSummary, "cpNload", "LONG")
        arcpy.AddField_management(DWMSummary, "cpNLoadReduced", "LONG")
        arcpy.AddField_management(DWMSummary, "cpWSNLoadPct", "float")
        
        arcpy.CalculateField_management(DWMSummary, "cropAcres", "!Shape_Area! * 0.000247", "PYTHON")
        arcpy.CalculateField_management(DWMSummary, "pctWScropAcres", "(!cropAcres! / %s) * 100.0" % int(AgAcres), "PYTHON")   
        arcpy.CalculateField_management(DWMSummary, "cpNload", "!NloadAc! * !cropAcres!", "PYTHON") # the N Load is only for the affected acres
        arcpy.CalculateField_management(DWMSummary, "cpNLoadReduced", "!cpNload! * %s" % float(0.33), "PYTHON") # the N Load is only for the affected acres
        arcpy.CalculateField_management(DWMSummary, "cpWSNLoadPct", "(!cpNLoadReduced! / %s) * 100.0" % (float(wsTotalNLoad)), "PYTHON")   
        
        # Calcuate direct costs J.Tyndall 06/2020
        #2020$	Annualized total	Annualized per treated acre
        #50 acre drainage	$1,295	$26
        #75 acre drainage	$1,843	$25
        #100 acre drainage	$2,470	$25
        #150 acre drainage	$3,488	$23
        arcpy.CalculateField_management(DWMSummary, "DirectCost", "!cropAcres! * 25", "PYTHON")
        arcpy.MakeFeatureLayer_management(DWMSummary, "LT50Lyr", "cropAcres <= 50")
        arcpy.CalculateField_management("LT50Lyr", "DirectCost", "!cropAcres! * 26", "PYTHON")
        arcpy.MakeFeatureLayer_management(DWMSummary, "GT150Lyr", "cropAcres >= 150")
        arcpy.CalculateField_management("GT150Lyr", "DirectCost", "!cropAcres! * 23", "PYTHON")   
        
        # Calculate N load reduction final costs
        arcpy.AddField_management(DWMSummary, "TotalCost", "FLOAT")
        arcpy.AddField_management(DWMSummary, "ReducedCostLB", "FLOAT")
        arcpy.CalculateField_management(DWMSummary,"TotalCost", "!DirectCost! + !OpportunityCosts!","PYTHON")
        arcpy.CalculateField_management(DWMSummary,"ReducedCostLB", "!TotalCost! / !cpNLoadReduced!","PYTHON")
        
        # update summary table
        dwmFields = ["FBndID","opAcres","DirectCost","OpportunityCosts","cropAcres","pctWScropAcres","cpNload","cpNLoadReduced","cpWSNLoadPct","TotalCost","ReducedCostLB"]
        updateSummaryTable(outScnTable,DWMSummary,dwmFields,'DWM','FBndID')
        
        keepFields = ["FBndID","opAcres","DirectCost","OpportunityCosts","cropAcres","pctWScropAcres","Nrate", "Nconc","cpNload","cpNLoadReduced","cpWSNLoadPct","TotalCost","ReducedCostLB"]
        DeleteFields(DWMSummary, keepFields)
        
        # cleanup
        arcpy.Delete_management("LT50Lyr")
        arcpy.Delete_management("GT150Lyr")
        del (jFields,dwmFields,keepFields)


    if BYF is not "":
        arcpy.AddMessage("processing By Field practices")
        byFDict = {'Cover Crops: Rye':['CCR',58,0.31,0.29],'Cover Crops: Oats':['CCO',58,0.28,0.0],'Living Mulch':['LVM',58,0.41,0.0],'N inhibitor':['NIH',9.4,0.09,0.0],'Extended Rotation':['NTT',73,0.42,0.0]}
        
        BYFSummary = os.path.join(outFGDB,"%s_practiceSummary" % byFDict.get(BYFtheme)[0])
        byFCost = byFDict.get(BYFtheme)[1]
        byFNred = byFDict.get(BYFtheme)[2]
        byFPred = byFDict.get(BYFtheme)[3]
        
        path,filename = os.path.split(BYF)
        arcpy.MakeFeatureLayer_management(BYF, "FBlayer", "isAG = 1")
        arcpy.CopyFeatures_management("FBlayer", BYFSummary)
        
        # By Field practices have no Opportunity costs
        
        # Calculate Direct Cost
        # Mean CoverCrops: $64 per acre ($2020 IA)
        # Mean CoverCrops: $73 per acre ($2021 IA)
        # Mean CoverCrops: $58 per acre ($2024 IA)
        arcpy.AddField_management(BYFSummary, "opAcres", "FLOAT")
        arcpy.AddField_management(BYFSummary, "DirectCost", "FLOAT")
        arcpy.AddField_management(BYFSummary, "OpportunityCosts", "FLOAT")
        arcpy.CalculateField_management(BYFSummary, "opAcres", "0", "PYTHON")
        arcpy.CalculateField_management(BYFSummary, "DirectCost", "(!Shape_Area! * 0.000247) * %s" % byFCost, "PYTHON")
        arcpy.CalculateField_management(BYFSummary, "OpportunityCosts", "0", "PYTHON")
        
        # the pre-calculated field N load information fromm the nutrient table
        jFields = ["GenLU","CropRotatn","CornYrs","N_6Yrs","Nrate","Nconc", "NloadAc","wsNLoad"]
        arcpy.JoinField_management(BYFSummary, "FBndID", inFB_NPTable,"FBndID", jFields)
        
        # Add and calculate the the Practice reduction fields...no watersheds here
        arcpy.AddField_management(BYFSummary, "cropAcres", "float")
        arcpy.AddField_management(BYFSummary, "pctWScropAcres", "float")
        arcpy.AddField_management(BYFSummary, "cpNload", "LONG")
        arcpy.AddField_management(BYFSummary, "cpNLoadReduced", "LONG")
        arcpy.AddField_management(BYFSummary, "cpWSNLoadPct", "float")
    
        arcpy.CalculateField_management(BYFSummary, "cropAcres", "!Shape_Area! * 0.000247", "PYTHON")
        arcpy.CalculateField_management(BYFSummary, "pctWScropAcres", "(!cropAcres! / %s) * 100.0" % int(AgAcres), "PYTHON")   
        arcpy.CalculateField_management(BYFSummary, "cpNload", "!NloadAc! * !cropAcres!", "PYTHON") # the N Load is only for the affected acres
        arcpy.CalculateField_management(BYFSummary, "cpNLoadReduced", "!cpNload! * %s" % float(byFNred), "PYTHON") # the N Load is only for the affected acres
        arcpy.CalculateField_management(BYFSummary, "cpWSNLoadPct", "(!cpNLoadReduced! / %s) * 100.0" % (float(wsTotalNLoad)), "PYTHON")   
    
        # Calculate N load reduction final costs
        arcpy.AddField_management(BYFSummary, "TotalCost", "FLOAT")
        arcpy.AddField_management(BYFSummary, "ReducedCostLB", "FLOAT")
        arcpy.CalculateField_management(BYFSummary,"TotalCost", "!DirectCost! + !OpportunityCosts!","PYTHON")
        arcpy.CalculateField_management(BYFSummary,"ReducedCostLB", "!TotalCost! / !cpNLoadReduced!","PYTHON")

        # update summary table
        byfFields = ["FBndID","opAcres","DirectCost","OpportunityCosts","cropAcres","pctWScropAcres","cpNload","cpNLoadReduced","cpWSNLoadPct","TotalCost","ReducedCostLB"]
        updateSummaryTable(outScnTable,BYFSummary,byfFields,BYFtheme,'FBndID')
        
        keepFields = ["FBndID","opAcres","DirectCost","OpportunityCosts","cropAcres","pctWScropAcres","Nrate", "Nconc","cpNload","cpNLoadReduced","cpWSNLoadPct","TotalCost","ReducedCostLB"]
        DeleteFields(BYFSummary, keepFields)

        # Klean Up aisle 3                  
        del (byFCost,byFNred,byFPred,jFields)
                                            
    # final sweep                           
    arcpy.Delete_management("gS_poly")  
    
        
##------------------------------------------------------------------------------
##------------------------------------------------------------------------------

if __name__ == "__main__":

    inFBnd = arcpy.GetParameterAsText(0)
    inLU6 = arcpy.GetParameterAsText(1)
    inFB_NPTable = arcpy.GetParameterAsText(2)
    gSSURGO = arcpy.GetParameterAsText(3)
    outFGDB = arcpy.GetParameterAsText(4)
    inFlowDir = arcpy.GetParameterAsText(5)
    inFlowAcc = arcpy.GetParameterAsText(6)
    NRW = arcpy.GetParameterAsText(7)
    BIO = arcpy.GetParameterAsText(8)
    DWM = arcpy.GetParameterAsText(9) 
    CBS = arcpy.GetParameterAsText(10) 
    STB = arcpy.GetParameterAsText(11)
    RIB = arcpy.GetParameterAsText(12)
    GWW = arcpy.GetParameterAsText(13) 
    BYF = arcpy.GetParameterAsText(14) 
    BYFtheme = arcpy.GetParameterAsText(15) 
    
    
    # Test for a join on inFBnd
    #-----------------------------------------------------------------------------
    basename = arcpy.Describe(inFBnd).baseName
    hasJoin = joinCheck(inFBnd)
    if hasJoin:
        basename = arcpy.Describe(inFBnd).baseName
        arcpy.AddError("Found a join on %s  that must be removed before running tool...QUITTING!!!!" % basename)
        sys.exit(0)
        
           
    # Input data    
    #-----------------------------------------------------------------------------
    #FileGDB output FGDB

    FileGDB= arcpy.Describe(inFBnd).path
    filename= arcpy.Describe(inFBnd).baseName
    inHUC = filename[-12:]
        
    arcpy.AddMessage("%s, %s, %s" %(FileGDB,filename,inHUC))
        
    outPath,scnGDB = os.path.split(outFGDB)
    if not arcpy.Exists(outFGDB):
         arcpy.CreateFileGDB_management(out_folder_path=outPath, out_name=scnGDB, out_version="CURRENT")

    outScnTable = os.path.join(outFGDB,'scenarioSummary')                 
    tileTable = os.path.join(FileGDB, 'DrainageTable' + inHUC)

    # workspace
    #-----------------------------------------------------------------------------
    env.workspace = FileGDB
    env.scratchWorkspace = outFGDB
    env.cellSize = inFlowDir
    env.snapRaster = inFlowDir

            
    # Process
    #-----------------------------------------------------------------------------
    AgAcres = calcAgAcres(inFBnd)
    
    wsTotalNLoad = getwsNLoad(inFB_NPTable)

    inMLRA = getMLRA(inFBnd)

    rRate = getRentRate(inMLRA)

    mkFB_NReductionTable(inFBnd, outScnTable, inLU6)
    
    extractOpportunityCosts(inHUC, inFBnd, inFB_NPTable, gSSURGO, outScnTable, NRW, BIO, DWM, CBS, STB, RIB, GWW, inFlowDir, inFlowAcc, AgAcres, wsTotalNLoad, tileTable)
                            
    env.extent = ""
    env.scratchWorkspace = ""

