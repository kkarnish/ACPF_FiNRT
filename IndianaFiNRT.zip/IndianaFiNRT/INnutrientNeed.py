# -----------------------------------------------------------------------------
# byFieldNutrientNeed.py
# -----------------------------------------------------------------------------
# Original coding: D.James 01/2018
#
# 02.2022 DEJ Updates for Pro and Beta release
#   - Move to use Python 3.x urllib
#   - Expand crop handling to include all inputs, not just C/S
#   - Use the ACPF_CDLlkup2021 table ROTVAL
#   - Use the USGS Albers projection (102039) on the service data
#
# 03.2024 KDK Edits for Indiana
#   - Edited existing software to include water leaching numbers for Indiana
#
# Of particular note is the need to address the source data for the query to work
#  against. Originally, the MLRA data are likely a feature class using an OBJECTID.
#  The current version (temporary?) uses a shapefile using a FID. It also appears
#  the shape file uses layer=1, while the feature class uses layer=0...not proofed.
#  As a result, the shapefile query is FID>0, feature class is OBJECTID>0.
# -----------------------------------------------------------------------------

# Import system modules
import arcpy
from arcpy import env
from arcpy.sa import *
import sys, string, os
from datetime import datetime
import json, ssl, urllib
from urllib.parse import urlencode
from urllib.request import urlopen

# Set extensions & environments
arcpy.CheckOutExtension("Spatial")

env.overwriteOutput = True
env.parallelProcessingFactor = "90%"


##--------------------------------------------------------------------------------------
## Modules
##

def joinCheck(lyr):
    fields = arcpy.Describe(lyr).fields
    basename = arcpy.Describe(lyr).baseName
    for field in fields:
        if field.name.find(basename) == 0:
            return True
    return False


def addMetadata(outFBNtable, paraDict):
    # Set the standard-format metadata XML file's path
    scriptPath = sys.path[0]
    src_file_path = os.path.join(scriptPath, "toolMetadata\FieldBndyNrate_mTemplate.xml")

    # Get the target item's Metadata object
    tgt_item_md = md.Metadata(outFBNtable)

    # Import the ACPF metadata content to the target item
    if not tgt_item_md.isReadOnly:
        tgt_item_md.importMetadata(src_file_path)
        tgt_item_md.title = os.path.split(outFBNtable)[1]
        tgt_item_md.credits = 'Analyst: %s' % getpass.getuser()

        src_desc = tgt_item_md.summary
        for key, value in paraDict.items():
            src_desc = src_desc + ('%s %s' % (key, value))
        tgt_item_md.summary = src_desc

        tgt_item_md.save()


def getMLRA(inFBnd):
    d = arcpy.Describe(inFBnd)
    xCoord = d.extent.XMin
    yCoord = d.extent.YMin
    inSR = d.SpatialReference.factoryCode

    # The US MLRA feature service (ArcGIS Online) URL and query arguments for the feature service - output in json
    # uri = "https://services.arcgis.com/SXbDpmb7xQkk44JV/arcgis/rest/services/US_MLRA/FeatureServer/query?"   ## factory code = 4269
    # payload = {"layerDefs":"[{'layerId':'0','where':'OBJECTID>0','outFields':'MLRARSYM,MLRA_NAME'}]",'geometry':'429307,4630946','geometryType':'esriGeometryPoint','inSR':'26915','spatialRel':'esriSpatialRelIntersects','outSR':'4269','datumTransformation':'','applyVCSProjection':'false','returnGeometry':'false','maxAllowableOffset':'','geometryPrecision':'4','sqlFormat':'standard','f':'pjson','token':''}

    # the ISU GISF MLRA/CO feature service - 2022
    uri = "https://ortho.gis.iastate.edu/arcgis/rest/services/ACPF/MLRA/FeatureServer/query?"
    payload = {"layerDefs": "[{'layerId':'1','where':'FID>0','outFields':'MLRARSYM,MLRA_NAME,WaterLeach'}]",
               'geometry': '429307,4630946', 'geometryType': 'esriGeometryPoint', 'inSR': '26915',
               'spatialRel': 'esriSpatialRelIntersects', 'outSR': '102039', 'datumTransformation': '',
               'applyVCSProjection': 'false', 'returnGeometry': 'false', 'maxAllowableOffset': '',
               'geometryPrecision': '4', 'sqlFormat': 'standard', 'f': 'pjson', 'token': ''}

    # update the geometry and spatial reference from the input feature class
    payload['geometry'] = '%s,%s' % (xCoord, yCoord)
    payload['inSR'] = inSR
    payload['outSR'] = inSR

    # encode the query
    # for Pro & python 3x
    data = urllib.parse.urlencode(payload).encode("utf-8")
    req = urllib.request.Request(uri, data)

    # arcpy.AddMessage(data)
    # certificate handling tnx AKHerz
    # cerificate applied for Python 3
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    jDict = json.loads(urllib.request.urlopen(req, context=ctx).read())
    arcpy.AddMessage(jDict)

    inMLRA = jDict['layers'][0]['features'][0]['attributes']['MLRARSYM']
    MLRA_NAME = jDict['layers'][0]['features'][0]['attributes']['MLRA_NAME']
    wtrLeach = jDict['layers'][0]['features'][0]['attributes']['WaterLeach']

    arcpy.AddMessage('You are working in MLRA: %s - %s' % (inMLRA, MLRA_NAME))

    return (inMLRA, wtrLeach)


def getWtrLeach(inMLRA):
    # MLRA and Water leaching (in)
    wtrLeachDict = {"108": 17.0, "110": 15.2, "111": 18.1, "114": 22.3, "115": 20.6, "120A": 21.7, "120B": 22.9, "120C": 23.3,
                 "121": 21.7, "122": 23.1, "97": 15.0, "98": 15.4, "99": 15.7}
    wtrLeach = wtrLeachDict.get(inMLRA)

    arcpy.AddMessage('Leaching value: %s ' % (wtrLeach))

    return (wtrLeach)


def mkFBNTable(inFBnd, outFBNtable, inLU6, inCSrate, wtrLeach):
    # Create output table "tempTable"
    tempTable = "tempTable"
    arcpy.CopyRows_management(inFBnd, tempTable)

    arcpy.AddMessage("build Table...")

    # join needed fields from land use table - "GenLU", "CropRotatn", "CropSumry", "CCCount"
    arcpy.JoinField_management(tempTable, "FBndID", inLU6, "FBndID", "GenLU;CropRotatn;CropSumry;CCCount")

    # Add core N fields to be calculated
    # Eventually we will want to include other crops receiveng fertilizer, not just corn
    arcpy.AddField_management(tempTable, "FertYrs", "short")  ## all crops
    arcpy.AddField_management(tempTable, "CornYrs", "short")
    arcpy.AddField_management(tempTable, "CCpairs", "short")
    arcpy.AddField_management(tempTable, "N_6Yrs", "long")
    arcpy.AddField_management(tempTable, "N_Annual", "long")

    arcpy.AddField_management(tempTable, "Nrate", "float")
    arcpy.AddField_management(tempTable, "Nconc", "float")
    arcpy.AddField_management(tempTable, "NloadAc", "float")
    arcpy.AddField_management(tempTable, "wsNload", "LONG")
    arcpy.AddField_management(tempTable, "NLoadReduced", "LONG")

    arcpy.AddMessage("Calculating...")

    # initially calculate all to 0
    # Eventually we will want to include other crops receiveng fertilizer, not just corn
    arcpy.CalculateField_management(tempTable, "FertYrs", "0", "PYTHON")  ## all crops
    arcpy.CalculateField_management(tempTable, "CornYrs", "0", "PYTHON")
    arcpy.CalculateField_management(tempTable, "CCpairs", "0", "PYTHON")
    arcpy.CalculateField_management(tempTable, "N_6Yrs", "0", "PYTHON")
    arcpy.CalculateField_management(tempTable, "N_Annual", "0", "PYTHON")

    arcpy.CalculateField_management(tempTable, "Nrate", "0", "PYTHON")
    arcpy.CalculateField_management(tempTable, "Nconc", "0", "PYTHON")
    arcpy.CalculateField_management(tempTable, "NloadAc", "0", "PYTHON")
    arcpy.CalculateField_management(tempTable, "wsNload", "0", "PYTHON")
    arcpy.CalculateField_management(tempTable, "NLoadReduced", "0", "PYTHON")

    # Create tableview in memory
    arcpy.MakeTableView_management(tempTable, "TView", "", "in_memory")

    # identify fields to loop through in cursor
    # theFields = ["CropRotatn", "CCCount", "CornYrs", "CCpairs", "Acres", "N_6Yrs"]
    # Eventually we will want to include other crops receiveng fertilizer, not just corn
    theFields = ["CropRotatn", "CCCount", "CornYrs", "CCpairs", "Acres", "N_6Yrs", "FertYrs"]  ## all crops

    # loop through table view - only where is ag > 0 (includes rowcrop and pasture)
    rows = arcpy.da.UpdateCursor("TView", theFields, "isAG > 0")
    arcpy.AddMessage("Summarizing...")
    for row in rows:

        # count # of years (in a 6 year rotation) of each of the following crops (corn, bean, sugarbeet, pasture, wheat, smallgrain, and legumes)
        # C: corn
        # B: soybean
        # E: Sugarbeets
        # P: Alfalfa, Pasture|Grass|Hay
        # W: Wheat
        # G: barley, small grains, rye, oats, millet, speltz, camelina, buckwheat, triticale
        # H: Sorghum
        # M: legumes
        FertNcount = ""
        cstrng = ""
        rotstr = str(row[0])

        cornCount = rotstr.count("C")
        beanCount = rotstr.count("B")
        sugarbeetCount = rotstr.count("E")
        pasturecount = rotstr.count("P")
        wheatCount = rotstr.count("W")
        smGrainCount = rotstr.count("H") + rotstr.count("G")
        legumeCount = rotstr.count("M")

        # Calculate Corn Count - # of years in corn - populate "CornYrs" field with this #
        cstrng = cstrng + str(cornCount)
        row[2] = cstrng

        # Calculate Corn Pairs Count (# of instances of corn following corn)
        row[3] = row[1][0]

        # RowCrop count
        rowCropCount = cornCount + beanCount + sugarbeetCount + wheatCount + smGrainCount + legumeCount

        # Fertilizer N Years
        # Eventually we will want to include other crops receiveng fertilizer, not just corn
        FertNCount = cornCount + sugarbeetCount + wheatCount + smGrainCount
        if SoybeanRate > 0:
            FertNCount = FertNCount + beanCount
        if PastRate > 0:
            FertNCount = FertNCount + pasturecount
        row[6] = FertNCount  ## all crops

        # Calculate a 6 year total N required by field - weighted by acres --------------------

        # CORN: corn years (excluding corn after corn) * corn soybean rate * acres
        cN = (float(row[2]) - float(row[3])) * CSRate * float(row[4])

        # CORN following CORN: corn following corn years * (CC rate) * acres
        ccN = float(row[3]) * float(CCRate) * float(row[4])

        # BEAN: bean years * corn soybean rate * (bean factor adjusted from CS rate) * acres
        sN = beanCount * float(SoybeanRate) * float(row[4])

        # SUGARBEET: sugarbeet years * corn soybean rate * (sugarbeet factor adjusted from CS rate) * acres
        gN = sugarbeetCount * float(SugarbeetRate) * float(row[4])

        # WHEAT: wheat years * corn soybean rate * (wheat factor adjusted from CS rate) * acres
        wN = wheatCount * float(WheatRate) * float(row[4])

        # SMALL GRAINS: small grain years * corn soybean rate * (small grain factor adjusted from CS rate) * acres
        sgN = smGrainCount * float(SmGrainRate) * float(row[4])

        # LEGUMES: legume years * corn soybean rate * (legume factor adjusted from CS rate) * acres
        lN = legumeCount * float(LegumeRate) * float(row[4])

        # if at least one year of rowcrop - pasture is 0, else: PASTURE: pasture years * corn soybean rate * (pasture factor adjusted from CS rate) * acres
        if rowCropCount > 0:
            pN = 0
        else:
            pN = pasturecount * float(PastRate) * float(row[4])

        # Define "N_6yrs" as the sum of all nitrogen from all 6 years
        # row[5] =  cN + ccN
        # someday we will use all fertilizer
        row[5] = cN + ccN + sN + gN + pN + wN + sgN + lN  ## all crops

        # cleanup
        del [cN, ccN, sN, wN, gN, pN, sgN, lN]
        del [rowCropCount, cornCount, beanCount, sugarbeetCount, wheatCount, smGrainCount, legumeCount, pasturecount]

        # update rows
        rows.updateRow(row)

        # cleanup
    del [theFields]

    # copy to output
    arcpy.CopyRows_management(tempTable, outFBNtable)

    # Calculate fields
    arcpy.CalculateField_management(outFBNtable, "N_Annual", "!N_6Yrs! / 6", "PYTHON")
    # arcpy.CalculateField_management(outFBNtable, "Nrate", "(!N_6Yrs! / !CornYrs!) / !Acres!", "PYTHON")  # the N rate is for the whole field
    # Eventually we will want to include other crops receiveng fertilizer, not just corn
    arcpy.CalculateField_management(outFBNtable, "Nrate", "(!N_6Yrs! / !FertYrs!) / !Acres!",
                                    "PYTHON")  # the N rate is for the whole field  ## all crops

    # N_Concentration = (5.72+1.33*EXP(0.0116*N_Rate))
    arcpy.CalculateField_management(outFBNtable, "Nconc", "5.72 + 1.33 * math.exp(0.0116*!Nrate!) ",
                                    "PYTHON")  # the N concentration is for the whole field

    # Pasture/Grass/Hay from K.Stefanik 5.2020
    # Forage 2.29 mg/L; Average prairie 0.32 mg/L; Total perennial vegetation average 1.15 mg/L
    arcpy.MakeTableView_management(outFBNtable, "isPasture", "isAg = 2")
    arcpy.CalculateField_management("isPasture", "Nconc", "1.15", "PYTHON")

    # N_LoadAcre = N_Conc*wtrLeach*27154*3.785/1000/453.6 or N_Conc*wtrLeach*0.22658264991181656
    arcpy.CalculateField_management(outFBNtable, "NloadAc", "!Nconc! * %s * 0.22658264991181656" % (wtrLeach),
                                    "PYTHON")  # the N concentration is for the whole field
    arcpy.CalculateField_management(outFBNtable, "wsNLoad", "!NloadAc! * !Acres!",
                                    "PYTHON")  # the watershed N Load is for the whole field

    # cleanup
    arcpy.Delete_management(tempTable)
    arcpy.Delete_management("isPasture")


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------

if __name__ == "__main__":

    inFBnd = arcpy.GetParameterAsText(0)
    inLU6 = arcpy.GetParameterAsText(1)
    CSRate = int(arcpy.GetParameterAsText(2))
    CCRate = arcpy.GetParameterAsText(3)
    SoybeanRate = float(arcpy.GetParameterAsText(4))
    SugarbeetRate = float(arcpy.GetParameterAsText(5))
    WheatRate = float(arcpy.GetParameterAsText(6))
    SmGrainRate = float(arcpy.GetParameterAsText(7))
    LegumeRate = float(arcpy.GetParameterAsText(8))
    PastRate = float(arcpy.GetParameterAsText(9))
    outFBNtable = arcpy.GetParameterAsText(10)

    # Test for a join on inFBnd
    basename = arcpy.Describe(inFBnd).baseName
    hasJoin = joinCheck(inFBnd)
    if hasJoin:
        basename = arcpy.Describe(inFBnd).baseName
        arcpy.AddError("Found a join on %s  that must be removed before running tool...QUITTING!!!!" % basename)
        sys.exit(0)

    # Input data -------------------------------------------------------------------------
    fbDesc = arcpy.Describe(inFBnd)
    FileGDB = os.path.dirname(fbDesc.catalogPath)

    # Environments -----------------------------------------------------------------------
    env.workspace = FileGDB

    # Process ----------------------------------------------------------------------------
    inMLRA, wtrLeach = getMLRA(inFBnd)

    wtrLeach = getWtrLeach(inMLRA)

    mkFBNTable(inFBnd, outFBNtable, inLU6, CSRate, wtrLeach)

    # Add custom metadata
    arcpy.AddMessage("updating metadata...")
    now = datetime.now()

    paraDict = {
        '\n\nACPF FiNRT Nutrient Requirements Tool V1b.0Pro     ': '\nRun Date: %s' % now,
        '\nField boundary features: ': inFBnd,
        '\nLandUse6 table: ': inLU6,
        '\nCorn/Soybean N rate: ': CSRate,
        '\nContinuous Corn N rate: ': CCRate,
        '\nSoybean N Rate: ': SoybeanRate,
        '\ngSugarbeet N rate: ': SugarbeetRate,
        '\nWheat N rate: ': WheatRate,
        '\nSmall Grain N rate: ': SmGrainRate,
        '\nLegume N rate: ': LegumeRate,
        '\nPasture N rate: ': PastRate,
        '\nOutput Field N table: ': outFBNtable
    }

    # addMetadata(outFBNtable, paraDict)