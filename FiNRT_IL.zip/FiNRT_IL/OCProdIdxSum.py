import arcpy

inSoil = r"C:\Users\kkarn\Documents\SUSAG\floodFinance\floodFinanceData.gdb\IA_Soils"
zone = r"C:\Users\kkarn\Documents\SUSAG\floodFinance\floodFinanceData.gdb\MLRA_IA"
outputGDB = r"C:\Users\kkarn\Documents\SUSAG\floodFinance\floodFinanceData.gdb"
keepFields = ["OBJECTID", "OCProdIdx"]

goodSoil = arcpy.management.DeleteField(inSoil, keepFields, "KEEP_FIELDS")
arcpy.ZonalStatisticsAsTable_ra(zone, goodSoil, "MLRA_REG_S", outputGDB + "\\IAMLRAavgSoil")